# DHEENA BANK Mobile Banking Prototype

An educational prototype of a modern mobile banking application built with **React**, **TypeScript**, **Tailwind CSS**, and **React Router**, following the HSBC mobile design language and color architecture (#DB0011).

> **Disclaimer**: This is a fictional prototype developed strictly for educational and demonstration purposes. All account numbers, balances, transactions, and names are simulated.

---

## 🚀 Features & Screen Flow

1. **Screen 0 - Welcome / Landing (`/` or `/welcome`)**
   - Blurred scenic mountain lake backdrop
   - Floating card with "Welcome to Dheena Bank"
   - "Yes, log on or register" (primary red) & "Not yet, open a new account" (outlined)
2. **Screen 0.5 - Login Page (`/login`)**
   - 3 Login Options: **6-digit PIN** (with numeric keypad), **Password** (username + password toggle), and **Biometric** (glowing Touch ID / Face ID scanner)
3. **Screen 1 - Digital Secure Key Intro (`/secure-key`)**
   - Vector phone illustration with 6 PIN dots
   - Key security explanations
4. **Screen 2 - Home / Bank Accounts (`/home`)**
   - Account Card: `SAVINGS ACCOUNT - RES` (`DB-XXXX-XXXX-1234`) with `₹2,50,999.00 INR` balance
   - Fast Action icons (Transfer, Pay Bills, mPassbook, Scan QR)
   - Menu list: *Bank Accounts >*, *Borrowing >*, *Cards >*, *Services >*
   - Bottom Nav: Home, Investment, Move Money, Support
5. **Screen 3 - People & Business (`/people-and-bills`)**
   - Grid of 8 circular contacts (`HR`, `CI`, `MR`, `RR`, `HI`, `B`, `RV`, `SB`) that link directly to transfer
   - Recent Transactions
   - 8 Bill Payment icons (Mobile Recharge, Postpaid, Electricity, Piped Gas, FASTag, Loan EMI, Rent, View All)
6. **Screen 4 - Electricity Bill Payment (`/electricity-bill`)**
   - Real-time search bar
   - Linked Account (*Sanskar Tower 1405*, Consumer #8392019482) with instant "Pay ₹15,000" action
   - Catalog of Indian electricity operators (Adani, BESCOM, CESC, Tata Power, Torrent Power, etc.)
7. **Screen 5 - Pay and Transfer Main (`/pay-and-transfer`)**
   - Domestic and international transfer options
   - Live RBI indicative Forex rates (USD, GBP, EUR, AED)
   - International payees list and "Add international payee" modal with IBAN/SWIFT verification
8. **Screen 6 - Transfer Form (`/transfer`)**
   - Pre-filled recipient, amount input, live available balance
   - 24-character reference counter, NEFT/IMPS/RTGS selection, date selection
   - Mandatory Terms & Conditions acceptance
9. **Screen 7 - Payment Completed (`/payment-success`)**
   - Green tick checkmark animation + celebratory confetti burst
   - Transaction receipt with recipient, amount, date, transaction ID
   - Share to clipboard & 1-click verification in physical mPassbook ledger
10. **Screen 8 - Investment (`/investment`)**
    - Mutual Funds total asset value (`50,571.13 INR`)
    - Visual asset allocation bar chart & `+573.63` unrealized gain
    - Wealth catalog (Mutual funds, Fixed Deposits, Sovereign Gold Bonds, NPS)
11. **Screen 9 - My Details / Support (`/profile`)**
    - Customer ID `98402914` (Vignesh Mohan)
    - Expandable modals for *Personal details*, *Contact details*, *Employment details*, and *KYC Declaration*
12. **Screen 10 - mPassbook Real Ledger (`/mpassbook`)**
    - **Authentic physical passbook view**: ruled ledger paper background, left red margin line, official digital ink stamp
    - **No big balance summary box**
    - 5-Column ledger: Date, Particulars/Narration, Withdrawal (Debit in Red), Deposit (Credit in Green), Balance
    - 20 dummy transactions with mathematical balance integrity + live updates on new transactions
    - Print button (`window.print()`) & Download CSV button
    - Mandatory educational watermark

---

## 💻 How to Run Locally

### Prerequisites
- Node.js (version 18 or newer)
- npm or pnpm or yarn

### Installation
```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev
```

Open `http://localhost:3000` in your web browser.

### Build for Production
```bash
npm run build
npm run preview
```

---

## 🎨 Theme Specifications
- **Primary Red**: `#DB0011`
- **Background**: `#F5F5F5`
- **Cards**: `#FFFFFF` with elevated drop shadows
- **Text**: Black (`#000000`)
- **Ledger Font**: IBM Plex Mono & Courier Prime
